// testing a concept: Android Golf-GPS application
// TODO:
// 1. Get your current GPS coordinates using hardware reading or 
//    a software fix (see Skyhook Wireless)
// 2. Compute distance from your current location to hole's markers held
//    in the kml resource/sdcard file
// 3. Provide a reasonable interface showing prominently distance to
//    center, front, back of the green (perhaps to each marker ahead 
//    of you)
// 4. Switch automatically from one hole to the next 
// 5. Beautify your app adding score card, statistics, advice, ....
//
// -------------------------------------------------------------------------
// KML Data taken from BBGPSGolf webpage Dec-8-2010
// http://www.bbgpsgolf.com/viewcourselistg.php
// -------------------------------------------------------------------------
package cis493.golfing;

import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import android.app.Activity;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;

public class Golf extends Activity {
	double latYou = 41.596912; // your ball is by the trees on the right
	double lonYou = -81.433067;
	double latMiddleGreen = 41.5954647298964; // Manakiki GC Ohio
	double lonMiddleGreen = -81.4331665635109; // Manakiki GC Ohio
	final double METER_TO_YARDS = 1.0936133;
	double distance;
	int intDistance;
	EditText txtMsg;
	ArrayList<GolfMarker> lst = new ArrayList<GolfMarker>();

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		txtMsg = (EditText) findViewById(R.id.txtMsg);

		// calculating distance (yards) between two coordinates
		Location locationA = new Location("point: You");

		locationA.setLatitude(latYou);
		locationA.setLongitude(lonYou);

		Location locationB = new Location("point: Middle of the Green");

		locationB.setLatitude(latMiddleGreen);
		locationB.setLongitude(lonMiddleGreen);

		distance = locationA.distanceTo(locationB) * METER_TO_YARDS;
		intDistance = (int) Math.round(distance);

		txtMsg.setText("Middle: " + intDistance);

		/* ***********************************************************************
		 * Application will read a kml file holding <PlaceMarker>s for 
		 * Hole 1 at Manakiki Golf Course (Willoughby Hills, OH). A fragment of
		 * the kml file is depicted below. In this example file is saved in the 
		 * device's memory as an internal resource (better outside in the SDCard)
		 * ***********************************************************************
		 * 
		 * <?xml version='1.0' encoding='UTF-8'?> <kml
		 * xmlns='http://www.opengis.net/kml/2.2'> 
		 * <Document> 
		 * 	<gcname>Manakiki Golf Course</gcname> 
		 * 	<Placemark> 
		 * 		<name>Tee - Hole 1</name> 
		 * 		<Point>
		 * 			<coordinates>-81.4324182271957,41.5984273639879,0</coordinates>
		 * 		</Point> 
		 * 	</Placemark> 
		 * 	<Placemark> 
		 * 		<name>Front of Green - Hole 1</name> 
		 * 		<Point>
		 * 			<coordinates>-81.433182656765,41.5955730479591,0</coordinates>
		 * 		</Point> 
		 * 	</Placemark> 
		 * </Document> 
		 * </Kml>
		 * 
		 * 
		 * **********************************************************************
		 * ******
		 */
		// extract and display the whole kml file. create a list of GolfMarkers
		String xmlData = "";
		try {
			xmlData = getEventsFromXMLParser(this);
		} catch (XmlPullParserException e) {
			Log.e("<<Parser Error>>", e.getMessage());
		} catch (IOException e) {
			Log.e("<<IO Error>>", e.getMessage());
		}

		// show the summary information held as a list of GolfMarkers
		txtMsg.append("\n" + xmlData);
		for (GolfMarker g : lst) {
			txtMsg.append("\n" + g.toString());
		}

	}// onCreate

	// --------------------------------------------------------------
	// react to each event seen in the parsing of the kml file
	// while reading the file construct a summary arraylist

	private String getEventsFromXMLParser(Activity activity)
			throws XmlPullParserException, IOException {
		StringBuffer stringBuffer = new StringBuffer();
		Resources xmlFile = activity.getResources();
		XmlResourceParser xmlToken = xmlFile.getXml(R.xml.manakiki_hole1);

		String tagName = "";
		String tagValue = "";
		String previousTagName = "";

		xmlToken.next();
		int eventType = xmlToken.getEventType();
		while (eventType != XmlPullParser.END_DOCUMENT) {
			if (eventType == XmlPullParser.START_DOCUMENT) {
				// stringBuffer.append("<--- Start XML --->");
			} else if (eventType == XmlPullParser.START_TAG) {
				// stringBuffer.append("\nSTART_TAG: " + xmlToken.getName());

				tagName = xmlToken.getName();

			} else if (eventType == XmlPullParser.END_TAG) {
				// stringBuffer.append("\nEND_TAG: " + xmlToken.getName());
			} else if (eventType == XmlPullParser.TEXT) {
				// stringBuffer.append("\nTEXT: " + xmlToken.getText());
				if (tagName.equals("name")) {
					previousTagName = xmlToken.getText();
				}
				if (tagName.equals("coordinates")) {
					tagValue = xmlToken.getText();
					GolfMarker gm = new GolfMarker(previousTagName, tagValue);
					lst.add(gm);
				}
			}
			eventType = xmlToken.next();
		}
		// stringBuffer.append("\n<--- End XML --->");
		return stringBuffer.toString();
	}// getEventsFromXMLParser

	// -------------------------------------------------------------------------
	// embedded class represents a single mapped point of the golf course
	// -------------------------------------------------------------------------
	class GolfMarker {
		public String title;
		public String value;
		public String lat;
		public String lon;

		public GolfMarker(String theTitle, String theValue) {
			title = theTitle.trim();
			value = theValue;
			// get lat, lon if possible from value
			int firstComma = theValue.indexOf(",");
			int secondComma = theValue.indexOf(",", firstComma + 1);
			if (firstComma > 0) {
				lat = theValue.substring(0, firstComma - 1);
				lon = theValue.substring(firstComma + 1, secondComma - 1);
			}
		}

		public String toString() {
			return ("\n" + title + "\n\tLat: " + lat + "\n\tLon: " + lon);
		}

	}// GolfMarker

}// class

