package com.white_wizard_productions_inc.gridworld_chess;

import info.gridworld.actor.Actor;
import info.gridworld.grid.BoundedGrid;

public class ChessBoard extends BoundedGrid<Actor> {
	
	public ChessBoard() {
		super(8, 8);
	}
	
}
