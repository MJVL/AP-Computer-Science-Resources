/*
 * MyWizardSettingsValues.java
 *
 * Created on February 2, 2007, 10:27 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.tomwheeler.example.basicwizard;

/**
 *
 * @author twheeler
 */
public final class MyWizardSettingsValues {

    private MyWizardSettingsValues() {
        // hidden, since we just have static fields
    }

    // actual values are not important; they are just used as keys in a map
    // and therefore have to be unique.

    public static final String PROP_TEXT_ONE = "firstText";

    public static final String PROP_TEXT_TWO = "secondText";

    public static final String PROP_CHECKED = "checkboxChecked";

}
