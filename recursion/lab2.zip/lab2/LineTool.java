package lab2;
/**
 * Name:
 * Lab Section: 
 * Date:
 * Email:
 * LineTool.java
 * CSE 131 Lab 2
 */

import yops.*;
import java.awt.Color;
import java.awt.Point;

public class LineTool {
	Point start = new Point(0,0);
	Point end = new Point(0,0);
	Line temporaryLine = new Line(0, 0, 0, 0);
	boolean dashed = false;
	int dashLength = 0;

	// Complete this method to draw a line recursively by coloring pixels in the image.
	// When you color the pixels, use Color.RED as the color value so your line will be red.
	void drawLine(Image image, double x1, double y1, double x2, double y2) {

	}
	
	// Complete this method to draw a dashed line recursively by coloring pixels in the image.
	// The last parameter is the desired (approximate) length of the dashes and spaces.
	// Hint: At some recursive calls, you may make a call to your drawLine method.
	void drawDashedLine(Image image, double x1, double y1, double x2, double y2, int dashLength) {

	}

	public void setDashed(boolean dashed) {
		this.dashed = dashed;
	}
	
	public void setDashLength(int dashLength) {
		this.dashLength = dashLength;
	}
	
	void mousePressed(GraphicsPanel panel, int x, int y) {
		start.x = x;
		start.y = y;
		temporaryLine.setCorners(x,y,x,y);
		panel.add(temporaryLine);
	}
	
	void mouseDragged(GraphicsPanel panel, int x, int y) {
		if (panel.getBounds().contains(x,y)) {
			end.x = x;
			end.y = y;
			temporaryLine.setCorners(start.x, start.y, end.x, end.y);
		}
	}
	
	void mouseReleased(GraphicsPanel panel, int x, int y) {
		panel.remove(temporaryLine);
		if (dashed)
			drawDashedLine(panel.getMainImage(), start.x, start.y, end.x, end.y, dashLength);
		else
			drawLine(panel.getMainImage(), start.x, start.y, end.x, end.y);
	}
	
	// This method will appear in the YOPS menu, in case you want to clear the display during testing.
	void clear(GraphicsPanel panel) {
		panel.clear();
		Image img = panel.getMainImage();
		img.fillRegion(0, 0, img.getWidth(), img.getHeight(), Color.WHITE);
	}
	
	public String toString() {
		return "lines";
	}
	
	public static void main(String args[]) {
		new YOPS(new LineTool(), 256, 256, 1);
	}

}
