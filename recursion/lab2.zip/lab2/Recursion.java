package lab2;
/**
 * Name:
 * Lab Section: 
 * Date:
 * Email:
 * Recursion.java
 * CSE 131 Lab 2
 */

public class Recursion {
	
	// Example:
	static int factorial(int k) {
		if (k == 0)
			return 1;
		else
			return k * factorial(k-1);
	}
	
	// Your methods go here.

}
