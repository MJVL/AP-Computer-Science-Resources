package lab2;
/**
 * Name:
 * Lab Section: 
 * Date:
 * Email:
 * PatternTool.java
 * CSE 131 Lab 2
 */

import yops.*;

import java.awt.Color;
import java.util.Random;

public class PatternTool {
	static Random random = new Random();  // A random number generator, used to create colors.
	
	// Your methods go here.
	
	
	
	// For the "flower" pattern, you can call the following method to generate random
	// colors.  However, for the "Persian recursion" pattern, you should use
	// an instance of the provided ColorPalette class to create a set of colors for your rug.
	static Color randomColor() {
		return new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256), 175);
	}
	
	// This method will appear in the YOPS menu, in case you want to clear the display during testing.
	void clear(GraphicsPanel panel) {
		panel.clear();
		Image img = panel.getMainImage();
		img.fillRegion(0, 0, img.getWidth(), img.getHeight(), Color.WHITE);
	}
	
	public String toString() {
		return "patterns";
	}
	
	public static void main(String args[]) {
		new YOPS(new PatternTool(), 256, 256, 1);
	}

}
