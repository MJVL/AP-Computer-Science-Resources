package lab2;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Name:
 * Lab Section: 
 * Date:
 * Email:
 * RecursionTest.java
 * CSE 131 Lab 2
 */

public class RecursionTest {

	    // Example:
		@Test
		public void testFactorial() {
			assertEquals(1, Recursion.factorial(0));
			assertEquals(24, Recursion.factorial(4));
		}
		
		// Your test methods go here.
}
